#include "Date.h"
#include "Medication.h"
#include "OffTheShelf.h"
#include <iostream>
#include <ctime>
using namespace std;

time_t Now = time(NULL);
tm* dateNow = localtime(&Now);

int yearToday = dateNow->tm_year + 1900;
 int monthToday = 1 + dateNow->tm_mon;
 int dayToday = dateNow->tm_mday;

OffTheShelf::OffTheShelf()
{
    BOGOF = false;
    OfferEnds.setDay(dayToday);
    OfferEnds.setMonth(monthToday);
    OfferEnds.setYear(yearToday + 2);
}
OffTheShelf::OffTheShelf(string name, string description, float pr, int stock, Date& expiry_d, string bcode, bool bogof) : Medication(name, description, pr, stock, expiry_d, bcode)
{
    setBOGOF(bogof);
}

void OffTheShelf::setBOGOF(bool bogof)
{
    BOGOF = bogof;
    if (BOGOF)
    {
        OfferEnds.setDay(dayToday);
        OfferEnds.setMonth(monthToday + 3);
        OfferEnds.setYear(yearToday);
    }
    else
    {
        OfferEnds.setDay(dayToday);
        OfferEnds.setMonth(monthToday);
        OfferEnds.setYear(yearToday + 2);
    }
}
bool OffTheShelf::getBOGOF() { return BOGOF; }
Date OffTheShelf::getOfferEnd() { return OfferEnds; }

void OffTheShelf::print()
{
    Medication::print();
    cout << "Buy 1 Get 1 Free: ";
    if (BOGOF)
        cout << "Yes\n";
    else
        cout << "No\n";
    cout << "Offer Ends: ";
    OfferEnds.print();
}