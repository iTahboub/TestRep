#include "Customer.h"
#include "Medication.h"
#include "Address.h"
#include "Pharmacy.h"
#include "Date.h"
#include <iostream>
#include <string>
using namespace std;


int Medication::MedIDgenerator = 0;
int Customer::CustomerIDgenerator = 0;
int Pharmacy::PharIDgenerator = 0;

int main()
{
	int pharmacychoice, choice;
	//count is to track how many pharmacies the user added
	//index is used to indicate which pharmacy is being edited
	int pharmacycount = 0, pharmacyIndex = -1;
	Pharmacy *ph1 = new Pharmacy[pharmacycount];

	// phase 2

	//Pharmacy ph1[10];
	

	while (true)
	{
		cout << "|*---------------------------Pharmacy Management System-----------------------------*|" << endl;
		cout << endl;
		cout << "(1)  Add New Pharmacy                      " << endl;
		cout << "(2)  View Pharmacy                         " << endl;
		cout << "(3)  Exit                                  " << endl;
		//cout << "(4)  Resize Pharmacy array                                  " << endl;

		cout << "Please enter : ";
		cin >> pharmacychoice;

		// user cannot view a pharmacy if none are added
		if (pharmacychoice == 2 && pharmacycount == 0)
			cout << "No Pharmacies are Available\n";

		// validation of users entry
		else if (pharmacychoice < 1 || pharmacychoice > 3)
			cout << "invalid entry!\n";
		
		else if (pharmacychoice == 3)
		{
			cout << "EXITING...";
			return 0;
		}
		else
		{
			if (pharmacychoice == 1)
			{
				pharmacycount++;
				pharmacyIndex = pharmacycount - 1;
				Pharmacy *temp = new Pharmacy[pharmacycount];
				for (int i = 0; i < pharmacycount-1;i++){
					temp[i].setPharID(ph1[i].getPharID());
					temp[i].setName(ph1[i].getName());
					temp[i].set_med(ph1[i].get_Med(),ph1[i].get_medsize());
            		temp[i].set_cust(ph1[i].get_Cust(),ph1[i].get_custsize());
				}
				delete[] ph1;
				ph1 = temp;
				temp = NULL;
				string pharmacyName;
				cout << "Enter Name of Pharmacy: ";
				cin >> pharmacyName;
				ph1[pharmacyIndex].setName(pharmacyName);
				
			}
			if (pharmacychoice == 2)
			{
				cout << "Enter ID of Pharmacy to View: ";
				int pharmacyID;
				bool flag = false;
				do
				{
					cin >> pharmacyID;
					for (int i = 0; i < pharmacycount; i++)
						if (ph1[i].getPharID() == pharmacyID)
						{
							pharmacyIndex = i;
							flag = true;
							break;
						}
					if (!flag)
						cout << "No Pharmacy is found. Enter a Valid ID: ";
				} while (!flag);
			}
			do
			{
				cout << "|*-------------( " << ph1[pharmacyIndex].getPharID() << " ) " << ph1[pharmacyIndex].getName() << " Pharmacy Control-------------*|" << endl;
				cout << endl;
				cout << "(1)  Add New Medication(s) in the Pharmacy                      " << endl;
				cout << "(2)  Add New Customer(s) in the Pharmacy                       " << endl;
				cout << "(3)  Remove a Medication                     " << endl;
				cout << "(4)  Display Medications                      " << endl;
				cout << "(5)  Display Customers                       " << endl;
				cout << "(6)  Back to Adding Pharmacies     " << endl;
				cout << "(7)  Exit                    " << endl;
				cout << endl;
				cout << "Please enter : ";
				cin >> choice;
				cout << endl;

				switch (choice)
				{
				case 1:
				{
					int num_of_med;
					cout << "\nEnter number of Medications you want to add : ";
					cin >> num_of_med;
					ph1[pharmacyIndex].add_med(num_of_med);
					break;
				}
				case 2:
				{
					int num_of_cust;
					cout << "\nEnter number of Customers you want to add : ";
					cin >> num_of_cust;
					ph1[pharmacyIndex].add_cust(num_of_cust);
					break;
				}
				case 3:
				{
					cout << "\nEnter the ID of the medication you want to remove : ";
					int removed;
					cin >> removed;
					ph1[pharmacyIndex].remove_med(removed);
					break;
				}
				case 4:
				{
					cout << "\nMediacation set : \n";
					ph1[pharmacyIndex].display_med();
					break;
				}
				case 5:
				{
					cout << "\nCustomer set : \n";
					ph1[pharmacyIndex].display_customer();
					break;
				}
				case 6:
				{
					break;
				}
				case 7:
				{
					cout << "EXITING...";
					return 0;
					break;
				}
				default:
					cout << "invalid entry!\n";
				}

			} while (choice != 6);
		}
	}

	return 0;
}


//g++ pharmacy.cpp medication.cpp customer.cpp address.cpp date.cpp driver.cpp prescribtion.cpp offtheshelf.cpp