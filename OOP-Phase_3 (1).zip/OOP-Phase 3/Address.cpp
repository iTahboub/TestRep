#include "Address.h"
#include <iostream>
#include <string>

using namespace std;

Address::Address(string mail, string c, string n, string s_name) {

    email = mail;
    city = c;
    mobile_num = n;
    street_name = s_name;

}

Address::Address() {
    email = "Johndoe@gmail.com";
    city = "New York";
    mobile_num = "0000000000";
    street_name = "Wall Street";

}

void Address::setMail(string m) {
    while (m == "") {
        cout << "Enter Valid Email: " << endl;
        getline(cin, m);
    }
    email = m;

}

void Address::setCity(string C) {
    while (C == "") {
        cout << "Enter Valid City: " << endl;
        getline(cin, C);
    }
    city = C;
}
void Address::setNum(string num) {
    while (num == "") {
        cout << "Enter Valid Mobile Number: " << endl;
        getline(cin, num);
    }
    mobile_num = num;
}
void Address::setStreet(string s) {
    while (s == "") {
        cout << "Enter Valid Street Name: " << endl;
        getline(cin, s);
    }
    street_name = s;
}
string Address::getMail() {
    return email;
}
string Address::getCity() {
    return city;
}
string Address::getNum() {
    return mobile_num;
}
string Address::getStreet() {
    return street_name;
}
void Address::print() {
    cout << "Address Info\n" << "Email: " << email;
    cout << "\nCity: " << city;
    cout << "\nStreet Name: " << street_name;
    cout << "\nPhone Number: " << mobile_num;

};



