#ifndef PHARMACY_H
#define PHARMACY_H
#include <string>
#include <iostream>
#include"Medication.h"
#include"Customer.h"

using namespace std;

class Pharmacy {
private:
	int pharmacy_ID;
	string pharmacy_name;
	Medication* med;
	Customer* cust;
	static int PharIDgenerator;
	int medsize;
	int custsize;
	//int index_med;
	//int index_cust;

public:
	Pharmacy();
	Pharmacy(string phName, Medication m1[], Customer c1[], int med_size, int cust_size);
	Pharmacy(const Pharmacy& other);
	~Pharmacy();
	void add_med(int num);
	int get_med();
	void remove_med(int medID);
	//to copy to new object

    void set_med(Medication m[],int s);
    void set_cust(Customer c[],int s);
    void set_medsize(int size);
    void set_custsize(int size);
	void add_cust(int num);
	
    Medication* get_Med() const ;
    Customer * get_Cust() const;

	int get_medsize() const;
	int get_custsize();
	void display_med();
	void display_customer();
	void setName(string);
	string getName();
	int getPharID() const;
	void setPharID(int);
};

#endif // !PHARMACY_H
