#ifndef Medication_h
#define Medication_h
#include <iostream>
#include "Date.h"
#include <string>

using namespace std;

class Medication {
private:
	string MedName;
	string MedDescription;
	float price;
	int QinStock;
	Date expiryDate;
	string barcode;
	int MedID;
	static int MedIDgenerator;

public:
	//constructors
	Medication();
	Medication(string name, string description, float pr, int stock, Date& expiry_d, string bcode);
	Medication(const Medication&);

	//setters
	void setName(string name);
	void setDescription(string description);
	void setPrice(float pr);
	void setStock(int stock);
	void setDate(Date expiry_d);
	void setBarcode(string bcode);
	void setMedID(int);

	//getters
	string getName();
	string getDescription();
	float getPrice();
	int getMedID() const;
	int getStock();
	Date getDate();
	string getBarcode();

	void print();

	void expiredMed();

};
#endif