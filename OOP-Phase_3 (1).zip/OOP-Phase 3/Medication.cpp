#include "Medication.h"
#include "Address.h"
#include "Pharmacy.h"
#include "Customer.h"
#include "Date.h"
#include<iostream>
#include <ctime>
#include <string>
using namespace std;

time_t Now_ = time(NULL);
tm* dateNow_ = localtime(&Now_);

int yearToday_ = dateNow_->tm_year + 1900;
int monthToday_ = 1 + dateNow_->tm_mon;
int dayToday_ = dateNow_->tm_mday;

Medication::Medication() :MedID(++MedIDgenerator) {
    MedName = "No Name";
    MedDescription = "No Description";
    price = 0;
    QinStock = 0;
    expiryDate.setDay(1);
    expiryDate.setMonth(1);
    expiryDate.setYear(2023);
    barcode = "No Barcode";
}

Medication::Medication(string name, string description, float pr, int stock, Date& expiry_d, string bcode) :MedID(++MedIDgenerator), expiryDate(expiry_d) {
    setName(name);
    setPrice(pr);
    setDescription(description);
    setStock(stock);
    setDate(expiry_d);
    setBarcode(bcode);
}
Medication::Medication(const Medication& m) :MedID(++MedIDgenerator) {
    MedName = m.MedName;
    MedDescription = m.MedDescription;
    price = m.price;
    QinStock = m.QinStock;
    expiryDate = m.expiryDate;
    barcode = m.barcode;
}

void Medication::setName(string name) {
    while (name == "") {
        cout << "Enter valid name" << endl;
        cin >> name;
    }
    MedName = name;
}
void Medication::setDescription(string description) {
    while (description == "") {
        cout << "Enter valid description" << endl;
        cin >> description;
    }
    MedDescription = description;
}
void Medication::setPrice(float pr) {
    while (price < 0) {
        cout << "Enter valid price" << endl;
        cin >> pr;
    }
    price = pr;
}
void Medication::setStock(int stock) {
    while (stock < 0) {
        cout << "Enter valid quantity" << endl;
        cin >> stock;
    }
    QinStock = stock;
}
void Medication::setDate(Date expiry_d) {
    expiryDate.setDay(expiry_d.getDay());
    expiryDate.setMonth(expiry_d.getMonth());
    expiryDate.setYear(expiry_d.getYear());
}
void Medication::setBarcode(string bcode) {
    while (bcode.length() != 11) {
        cout << "Enter valid barcode" << endl;
        cin >> bcode;
    }
    barcode = bcode;
}

string Medication::getName() { return MedName; }
string Medication::getDescription() { return MedDescription; }
float Medication::getPrice() { return price; }
int Medication::getStock() { return QinStock; }
Date Medication::getDate() { return expiryDate; }
int Medication::getMedID() const { return MedID; }
string Medication::getBarcode() { return barcode; }

void Medication::print() {
    cout << "Medication ID: " << MedID << endl;
    cout << "Medication Name: " << MedName << endl;
    cout << "Description: " << MedDescription << endl;
    cout << "Price: " << price << endl;
    cout << "Quantity in Stock: " << QinStock << endl;
    cout << "Expiry Date: ";
    expiryDate.print();
    cout << "Barcode: " << barcode << endl;
    expiredMed();
}

void Medication::expiredMed() {
    //not expired only when year of expiry is later than current year
    if(expiryDate.getYear() > yearToday_)
        return;
    //soon to expire only when year of expiry is the same as current year && it hasnt expired yet
    if ((expiryDate.getYear() == yearToday_ && expiryDate.getMonth() > monthToday_) ||
       (expiryDate.getYear() == yearToday_ && expiryDate.getMonth() == monthToday_ && expiryDate.getDay() > dayToday_)) {
        cout << "Medication is soon to expire\n";
    } else {
        cout << "Medication has expired\n";
    }

}

void Medication::setMedID(int mid){
    MedID = mid;
}