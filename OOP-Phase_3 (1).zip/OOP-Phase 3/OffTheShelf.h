#pragma once
#include "Medication.h"
#include "Date.h"

class OffTheShelf :public Medication {
protected:
	bool BOGOF;
	Date OfferEnds;
public:
	OffTheShelf();
	OffTheShelf(string name, string description, float pr, int stock, Date& expiry_d, string bcode, bool bogof);

	void setBOGOF(bool);

	bool getBOGOF();
	Date getOfferEnd();

	void print();
};