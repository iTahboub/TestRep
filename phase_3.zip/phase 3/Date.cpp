#include <iostream>
using namespace std;
#include "Date.h"

Date::Date(int d, int m, int y) {
    day = d;
    month = m;
    year = y;
}
Date::Date(const Date& date) {
    day = date.day;
    month = date.month;
    year = date.year;
}
void Date::setDay(int d) {
    while (d < 1 || d > 31) {
        cout << "Enter valid day: ";
        cin >> d;
    }
    day = d;
}
void Date::setMonth(int m) {
    while (m < 1 || m > 12) {
        cout << "Enter valid month: ";
        cin >> m;
    }
    month = m;
}
void Date::setYear(int y) {
    while (y < 1923)
    {
        cout << "Enter valid year: ";
        cin >> y;
    }
    year = y;
}
int Date::getDay() { return day; }
int Date::getMonth() { return month; }
int Date::getYear() { return year; }
void Date::print() {
    cout << day << "/" << month << "/" << year << endl;
}