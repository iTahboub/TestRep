#ifndef Customer_h
#define Customer_h
#include "Address.h"
#include <string>
using namespace std;

class Customer {
private:
	string CustomerName;
	Address customerAddress;
	const int ID;
	static int CustomerIDgenerator;

public:
	//Constructors
	Customer();
	Customer(string name, const Address& ad, int id);
	Customer(Customer& other);

	//setters 
	void setName(string name);
	void setAdd(Address ad);

	//getters
	string getName();
	Address getAdd();
	int getId()const;

	void print();
};
#endif