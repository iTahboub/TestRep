#ifndef PHARMACY_H
#define PHARMACY_H
#include <string>
#include <iostream>
#include"Medication.h"
#include"Customer.h"

using namespace std;

class Pharmacy {
private:
    const int pharmacy_ID;
	string pharmacy_name;
	Medication *med;
	Customer *cust;
	static int PharIDgenerator;
	int medsize;
	int custsize;
	//int index_med;
	//int index_cust;

public:
	Pharmacy();
	Pharmacy(string phName, Medication m1[], Customer c1[], int med_size, int cust_size);
	~Pharmacy();
	void add_med(int num);
	void remove_med(int midID);
	void add_cust(int num);
	void display_med();
	void display_customer();
	void setName(string);
	string getName();
	int getPharID() const;
};

#endif // !PHARMACY_H
