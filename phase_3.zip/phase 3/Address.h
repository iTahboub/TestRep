#pragma once
#include <string>
using namespace std;
class Address {

private:
    string email;
    string city;
    string mobile_num;
    string street_name;

public:
    Address(string mail, string c, string n, string s_name);
    Address();
    void setMail(string m);
    void setCity(string C);
    void setNum(string num);
    void setStreet(string s);
    string getMail();
    string getCity();
    string getNum();
    string getStreet();
    void print();
};
