#include "Medication.h"
#include "Address.h"
#include "Pharmacy.h"
#include "Customer.h"
#include "Date.h"

#include <iostream>
#include <string>
using namespace std;


//Constuctors below

Customer::Customer() :ID(++CustomerIDgenerator) {
	CustomerName = "Null";
}

Customer::Customer(string name, const Address & ad, int id) :ID(++CustomerIDgenerator) {

	while (name == "") {
		cout << "Enter a valid entry : ";
		getline(cin, name);
	}
	CustomerName = name;

	customerAddress = ad;
}

Customer::Customer(Customer& other) :ID(other.ID) {
	CustomerName = other.CustomerName;
	customerAddress = other.customerAddress;
}

void Customer::setName(string name) {
	int i = 0;
	while (name == "") {
		cout << "Enter a valid entry : ";
		getline(cin, name);
	}
	CustomerName = name;
}

void Customer::setAdd(Address ad) {
	customerAddress.setMail(ad.getMail());
    customerAddress.setCity(ad.getCity());
    customerAddress.setNum(ad.getNum());
    customerAddress.setStreet(ad.getStreet());
	
}

string Customer::getName() {
	return CustomerName;
}

Address Customer::getAdd() {
	return customerAddress;
}

int Customer::getId() const {
	return ID;
}

void::Customer::print() {
	cout << "Customer Name : " << CustomerName;
	cout << "\nCustomer ID : " << ID << endl;
	customerAddress.print();
}