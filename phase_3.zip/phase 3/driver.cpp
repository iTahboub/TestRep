#include "Customer.h"
#include "Medication.h"
#include "Address.h"
#include "Pharmacy.h"
#include "Date.h"

#include <iostream>
#include <string>
using namespace std;

int Medication::MedIDgenerator = 0;
int Customer::CustomerIDgenerator = 0;
int Pharmacy::PharIDgenerator = 0;

int main()
{
	int pharmacychoice, choice;

	// phase 2

	Pharmacy ph1[10];
	//count is to track how many pharmacies the user added
	//index is used to indicate which pharmacy is being edited
	int pharmacycount = 0, pharmacyIndex = -1;

	while (true)
	{
		cout << "|*---------------------------Pharmacy Management System-----------------------------*|" << endl;
		cout << endl;
		cout << "(1)  Add New Pharmacy                      " << endl;
		cout << "(2)  View Pharmacy                         " << endl;
		cout << "(3)  Exit                                  " << endl;
		cout << "Please enter : ";
		cin >> pharmacychoice;
		// user cannot view a pharmacy if none are added
		if (pharmacychoice == 2 && pharmacycount == 0)
			cout << "No Pharmacies are Available\n";

		// validation of users entry
		else if (pharmacychoice < 1 || pharmacychoice > 3)
			cout << "invalid entry!\n";
		else if (pharmacychoice == 3)
		{
			cout << "EXITING...";
			return 0;
		}
		//user cannot add more than 10 pharmacies
		else if (pharmacychoice == 1 && pharmacycount == 10)
			cout << "Maximum number of pharmacies are added\n";
			else
			{
				if (pharmacychoice == 1)
				{
					pharmacycount++;
					pharmacyIndex = pharmacycount - 1;
					string pharmacyName;
					cout << "Enter Name of Pharmacy: ";
					cin >> pharmacyName;
					ph1[pharmacyIndex].setName(pharmacyName);
				}
				if (pharmacychoice == 2)
				{
					cout << "Enter ID of Pharmacy to View: ";
					int pharmacyID;
					bool flag = false;
					do
					{
						cin >> pharmacyID;
						for (int i = 0; i < pharmacycount; i++)
							if (ph1[i].getPharID() == pharmacyID)
							{
								pharmacyIndex = i;
								flag = true;
								break;
							}
						if (!flag)
							cout << "No Pharmacy is found. Enter a Valid ID: ";
					} while (!flag);
				}
				do
				{
					cout << "|*-------------( " << ph1[pharmacyIndex].getPharID() << " ) " << ph1[pharmacyIndex].getName() << " Pharmacy Control-------------*|" << endl;
					cout << endl;
					cout << "(1)  Add New Medication(s) in the Pharmacy                      " << endl;
					cout << "(2)  Add New Customer(s) in the Pharmacy                       " << endl;
					cout << "(3)  Remove a Medication                     " << endl;
					cout << "(4)  Display Medications                      " << endl;
					cout << "(5)  Display Customers                       " << endl;
					cout << "(6)  Back to Adding Pharmacies     " << endl;
					cout << "(7)  Exit                    " << endl;
					cout << endl;
					cout << "Please enter : ";
					cin >> choice;
					cout << endl;

					switch (choice)
					{
					case 1:
					{
						int num_of_med;
						cout << "\nEnter number of Medications you want to add : ";
						cin >> num_of_med;
						ph1[pharmacyIndex].add_med(num_of_med);
						break;
					}
					case 2:
					{
						int num_of_cust;
						cout << "\nEnter number of Customers you want to add : ";
						cin >> num_of_cust;
						ph1[pharmacyIndex].add_cust(num_of_cust);
						break;
					}
					case 3:
					{
						cout << "\nEnter the ID of the medication you want to remove : ";
						int removed;
						cin >> removed;
						ph1[pharmacyIndex].remove_med(removed);
						break;
					}
					case 4:
					{
						cout << "\nMediacation set : \n";
						ph1[pharmacyIndex].display_med();
						break;
					}
					case 5:
					{
						cout << "\nCustomer set : \n";
						ph1[pharmacyIndex].display_customer();
						break;
					}
					case 6:
					{
						break;
					}
					case 7:
					{
						cout << "EXITING...";
						return 0;
						break;
					}
					default:
						cout << "invalid entry!\n";
					}

				} while (choice != 6);
			}
	}

	return 0;
}


//g++ pharmacy.cpp medication.cpp customer.cpp address.cpp date.cpp driver.cpp