#pragma once
#include "Date.h"
#include "Medication.h"

class Prescribtion :public Medication {
protected:
	int FDA_Number;
	Date Approval_Date;
public:
	Prescribtion();
	Prescribtion(string name, string description, float pr, int stock, Date& expiry_d, string bcode, int fda, Date approvalD);
	
	void setFDAN(int num);
	void setApprovalDate(Date &);

	int getFDAN();
	Date getApprovalDate();

	void print();
};