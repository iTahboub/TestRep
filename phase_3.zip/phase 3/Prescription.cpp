#include "Date.h"
#include "Medication.h"
#include "Prescription.h"
#include <iostream>
using namespace std;

Prescribtion::Prescribtion()
{
    FDA_Number = 0;
    Approval_Date.setDay(1);
    Approval_Date.setMonth(1);
    Approval_Date.setYear(2023);
}
Prescribtion::Prescribtion(string name, string description, float pr, int stock, Date &expiry_d, string bcode, int fda, Date approvalD) : Medication(name, description, pr, stock, expiry_d, bcode)
{
    setFDAN(fda);
    setApprovalDate(approvalD);
}

void Prescribtion::setFDAN(int num)
{
    while (num < 0)
    {
        cout << "Enter valid number: ";
        cin >> num;
    }
    FDA_Number = num;
}
void Prescribtion::setApprovalDate(Date &approvelD)
{
    Approval_Date.setDay(approvelD.getDay());
    Approval_Date.setMonth(approvelD.getMonth());
    Approval_Date.setYear(approvelD.getYear());
}

int Prescribtion::getFDAN() { return FDA_Number; }
Date Prescribtion::getApprovalDate() { return Approval_Date; }

void Prescribtion::print(){
    Medication::print();
    cout << "FDA Number: " << FDA_Number << endl;
    cout << "Approval Date: ";
    Approval_Date.print();
}