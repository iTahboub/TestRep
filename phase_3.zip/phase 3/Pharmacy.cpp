#include "Pharmacy.h"
#include "Customer.h"
#include "Medication.h"
#include "Date.h"
#include "Address.h"
#include <iostream>
#include <string>
using namespace std;

Pharmacy::Pharmacy() : pharmacy_ID(++PharIDgenerator)
{
	pharmacy_name = "";
	med = NULL;
	cust=NULL;
	medsize = 0;
	custsize = 0;
}

Pharmacy::Pharmacy(string phName, Medication m1[], Customer c1[], int med_size, int cust_size) : pharmacy_ID(++PharIDgenerator)
{
	pharmacy_name = phName;
	if (med_size < 0) {
		medsize = 0;
	}
if (cust_size < 0) {
		custsize = 0;
	}

	med = new Medication[medsize];
	cust = new Customer[custsize];

	for (int i = 0; i < medsize; i++) {
		med[i].setName(m1[i].getName());
		med[i].setDescription(m1[i].getDescription());
		med[i].setPrice(m1[i].getPrice());
		med[i].setStock(m1[i].getStock());
		med[i].setDate(m1[i].getDate());
		med[i].setBarcode(m1[i].getBarcode());
	}

	for (int j = 0; j < custsize; j++) {
		cust[j].setName(c1[j].getName());
		cust[j].setAdd(c1[j].getAdd());
	}
}
Pharmacy::~Pharmacy() {
	if (med != NULL) {
		delete[] med;
	}
	if (cust != NULL) {
		delete[] cust;
	}
}
void Pharmacy::add_med(int num)
{
	if (medsize + num > medsize) {
		Medication* temp = new Medication[medsize + num];
		for (int i = 0; i < medsize; i++) {
			temp[i].setName(med[i].getName());
		}
		delete[] med;
		med = temp;
		temp = NULL;
	}

	for (int i = 0; i < num; i++) {
		string MedName, MedDescription, barcode;
			float price;
			int QinStock, expiryDay, expiryMonth, expiryYear;
			cout << "Enter Medication Name : ";
			cin >> MedName;
			med[i].setName(MedName);
			cout << "Enter Medication Description : ";
			cin >> MedDescription;
			med[i].setDescription(MedDescription);
			cout << "Enter Medication Price : ";
			cin >> price;
			med[i].setPrice(price);
			cout << "Enter Medication Quantity in stock : ";
			cin >> QinStock;
			med[i].setStock(QinStock);
			cout << "Enter Medication Expiry Date DD/MM/YY Respectively : ";
			cin >> expiryDay >> expiryMonth >> expiryYear;
			med[i].setDate(Date(expiryDay, expiryMonth, expiryYear));
			cout << "Enter Medication Barcode : ";
			cin >> barcode;
			med[i].setBarcode(barcode);

	}
}

void Pharmacy::remove_med(int MedID)
{
	Medication *temp = new Medication[--medsize];

	for (int i = 0; i < medsize; i++)
	{
		if (med[i].getMedID() != MedID)
		{
		med[i].setName(temp[i].getName());
		med[i].setDescription(temp[i].getDescription());
		med[i].setPrice(temp[i].getPrice());
		med[i].setStock(temp[i].getStock());
		med[i].setDate(temp[i].getDate());
		med[i].setBarcode(temp[i].getBarcode());
		}
		else
		{
			cout << "No medication removed" << endl;
		}
	}
}

void Pharmacy::add_cust(int num)
{
		Customer* temp = new Customer[custsize + num];
		for (int i = 0; i < custsize; i++) {
			temp[i].setName(cust[i].getName());
		}
		delete[] cust;
		cust = temp;
		temp = NULL;
		for (int i = 0; i < num; i++)
		{
			string cust_name, email, city, mobileNum, streetName;
			Address custAdd;

			cout << "\nEnter Name: ";
			cin >> cust_name;
			cust[i].setName(cust_name);
			cout << "\n**Address Info**\n";
			cout << "\nEnter email: ";
			cin >> email;
			custAdd.setMail(email);
			cout << "\nEnter City: ";
			cin >> city;
			custAdd.setCity(city);
			cout << "\nEnter Mobile Number: ";
			cin >> mobileNum;
			custAdd.setNum(mobileNum);
			cout << "\nEnter Street Name: ";
			cin >> streetName;
			custAdd.setStreet(streetName);
			cust[i].setAdd(custAdd);
		}
}

void Pharmacy::display_med()
{
	if (medsize == 0)
	{
		cout << "no medications available" << endl;
	}
	else
	{
		for (int i = 0; i < medsize; i++)
		{
			cout << "Medication #" << i + 1 << " Information:- \n";
			med[i].print();
		}
	}
}

void Pharmacy::display_customer()
{
	if (custsize == 0)
	{
		cout << "no customers" << endl;
	}
	else
	{
		for (int i = 0; i < custsize; i++)
		{
			cout << "Customer #" << i + 1 << " Information:- \n";
			cust[i].print();
		}
	}
}
void Pharmacy::setName(string name)
{
	while (name == "")
	{
		cout << "Enter valid name" << endl;
		cin >> name;
	}
	pharmacy_name = name;
}
string Pharmacy::getName() { return pharmacy_name; }
int Pharmacy::getPharID() const { return pharmacy_ID; }
