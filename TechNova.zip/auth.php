<?php
include 'config.php';
session_start();

$signup_error = $login_error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['signup'])) {
        // Signup logic
        $fullname = $_POST['fullname'];
        $email = $_POST['email'];
        $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

        $sql = "INSERT INTO users (fullname, email, password) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("sss", $fullname, $email, $password);
            if ($stmt->execute()) {
                $_SESSION['user_id'] = $conn->insert_id;
                $_SESSION['user_name'] = $fullname;
                header("Location: index.php");
                exit();
            } else {
                $signup_error = "Error: Unable to register.";
            }
            $stmt->close();
        } else {
            $signup_error = "Error: Unable to prepare statement.";
        }
    } elseif (isset($_POST['login'])) {
        // Login logic
        $email = $_POST['email'];
        $password = $_POST['password'];

        $sql = "SELECT * FROM users WHERE email = ?";
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['fullname'];
                header("Location: index.php");
                exit();
            } else {
                $login_error = "Invalid email or password.";
            }
            $stmt->close();
        } else {
            $login_error = "Error: Unable to prepare statement.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Auth | Tech Nova</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@48,400,0,0">
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <!-- Navbar Section -->
  <div class="navbar-container">
    <nav class="navbar">
      <div class="hamburger-btn">
        <span class="hamburger-btn material-symbols-rounded">menu</span>
      </div>
      <a href="/index.php" class="logo">
        <h2>Tech Nova</h2>
      </a>
      <ul class="links">
        <span class="close-btn material-symbols-rounded">close</span>
        <li><a href="index.php">Home</a></li>
        <li><a href="/products.php">Products</a></li>
        <li><a href="index.php#aboutus">About Us</a></li>
        <li><a href="index.php#contactus">Contact</a></li>
      </ul>
      <a href="auth.php"><button class="login-btn">LOGIN</button></a>
    </nav>
  </div>

  <!-- Auth Section -->
  <section class="wrapper">
    <!-- Signup Form -->
    <div class="form signup">
      <header>Signup</header>
      <?php if ($signup_error): ?>
        <p class="error"><?php echo $signup_error; ?></p>
      <?php endif; ?>
      <form id="signup-form" action="auth.php" method="POST" onsubmit="return validateSignupForm()">
        <input type="text" name="fullname" placeholder="Full name" required />
        <input type="email" name="email" placeholder="Email address" required />
        <input type="password" name="password" placeholder="Password" required />
        <div class="checkbox">
          <input type="checkbox" id="signupCheck" required />
          <label for="signupCheck">I accept all terms & conditions</label>
        </div>
        <input type="submit" name="signup" value="Signup" />
      </form>
    </div>

    <!-- Login Form -->
    <div class="form login">
      <header>Login</header>
      <?php if ($login_error): ?>
        <p class="error"><?php echo $login_error; ?></p>
      <?php endif; ?>
      <form id="login-form" action="auth.php" method="POST" onsubmit="return validateLoginForm()">
        <input type="email" name="email" placeholder="Email address" required />
        <input type="password" name="password" placeholder="Password" required />
        <a href="#">Forgot password?</a>
        <input type="submit" name="login" value="Login" />
      </form>
    </div>
  </section>

  <script>
    const wrapper = document.querySelector(".wrapper"),
      signupHeader = document.querySelector(".signup header"),
      loginHeader = document.querySelector(".login header");

    loginHeader.addEventListener("click", () => {
      wrapper.classList.add("active");
    });
    signupHeader.addEventListener("click", () => {
      wrapper.classList.remove("active");
    });

    // menu functionality
    const toggleButton = document.querySelector('.hamburger-btn');
    const closeButton = document.querySelector('.close-btn');
    const navbarLinks = document.querySelector('.links');

    toggleButton.addEventListener('click', () => {
      navbarLinks.classList.toggle('show-menu');
    });

    closeButton.addEventListener('click', () => {
      navbarLinks.classList.remove('show-menu');
    });

    // validation
    function validateSignupForm() {
      const form = document.getElementById('signup-form');
      const fullname = form.fullname.value.trim();
      const email = form.email.value.trim();
      const password = form.password.value.trim();
      const signupCheck = form.signupCheck.checked;

      if (!fullname || !email || !password || !signupCheck) {
        alert('All fields are required.');
        return false;
      }

      if (password.length < 6) {
        alert('Password must be at least 6 characters long.');
        return false;
      }

      return true;
    }

    function validateLoginForm() {
      const form = document.getElementById('login-form');
      const email = form.email.value.trim();
      const password = form.password.value.trim();

      if (!email || !password) {
        alert('Both email and password are required.');
        return false;
      }

      return true;
    }
  </script>
</body>
</html>
