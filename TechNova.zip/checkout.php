<?php
session_start();
include('config.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: auth.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $first_name = $_POST['first-name'];
    $last_name = $_POST['last-name'];
    $address = $_POST['address'];
    $email = $_POST['email'];
    $streetname = $_POST['streetname'];
    $buildingno = $_POST['buldingno'];
    $total = $_POST['total'];
    $cart = json_decode($_POST['cart'], true);

    // addddddd order into orders table
    $stmt = $conn->prepare("INSERT INTO orders (user_id, total, status, first_name, last_name, address, email, streetname, buildingno, created_at) VALUES (?, ?, 'Pending', ?, ?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("idssssss", $user_id, $total, $first_name, $last_name, $address, $email, $streetname, $buildingno);
    $stmt->execute();
    $order_id = $stmt->insert_id;
    $stmt->close();

    // add asdff each cart item into order_items table
    $stmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price, created_at) VALUES (?, ?, ?, ?, NOW())");
    foreach ($cart as $item) {
        $stmt->bind_param("iiid", $order_id, $item['id'], $item['quantity'], $item['price']);
        $stmt->execute();
    }
    $stmt->close();

    // clear cart from local storage
    echo "<script>
        localStorage.removeItem('cart');
        alert('Order placed successfully!');
        window.location.href = 'index.php';
    </script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Checkout | Tech Nova</title>
      <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
      <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@48,400,0,0">
      <link rel="stylesheet" href="style.css" />
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
</head>

<body>
    <!-- Navbar Section -->
    <div class="navbar-container">
        <nav class="navbar">
            <div class="hamburger-btn">
                <span class="hamburger-btn material-symbols-rounded">menu</span>
            </div>
            <a href="/index.php" class="logo">
                <h2>Tech Nova</h2>
            </a>
            <ul class="links">
                <span class="close-btn material-symbols-rounded">close</span>
                <li><a href="index.php">Home</a></li>
                <li><a href="/products.php">Products</a></li>
                <li><a href="index.php#aboutus">About Us</a></li>
                <li><a href="index.php#contactus">Contact</a></li>
            </ul>
            <?php if (isset($_SESSION['user_id'])): ?>
                <div class='menuitem shoppingcart'>
                    <a href="cart.php"><i class="fa fa-shopping-cart fa-3x" aria-hidden="true"></i></a>
                </div>
            <?php else: ?>
                <a href="auth.php"><button class="login-btn">LOGIN</button></a>
            <?php endif; ?>
        </nav>
    </div>

    <div class="check-body">
            <div class="checkout-style">
                <form method="post" id="checkout-form">
                    <h1 class="title-style">Checkout</h1>
                    <div class="checkout-input">
                        <input type="text" name="first-name" placeholder="First Name" required class="checkout-text firstname" />
                        <input type="text" name="last-name" placeholder="Last Name" required class="checkout-text lastname" />
                    </div>
                    <div class="checkout-input">
                        <input type="text" name="address" placeholder="Address" required class="checkout-text" /><br>
                    </div>
                    <div class="checkout-input">
                        <input type="email" name="email" placeholder="Email" required class="checkout-text" /><br>
                    </div>
                    <h3 class="title-style">Address Details</h3>
                    <div class="checkout-input">
                        <input type="text" name="streetname" placeholder="Street Name" required class="checkout-text" /><br>
                    </div>
                    <div class="checkout-input">
                        <input type="text" name="buldingno" placeholder="Building No." required class="checkout-text" /><br>
                    </div>
                    <input type="hidden" name="total" id="total">
                    <input type="hidden" name="cart" id="cart">
                    <input type="submit" value="Confirm" class="con-button" id="checkout-button" /><br><br>
                </form>
            </div>
            <div class="summary" id="summary">
                <!-- dynamically insert summarryyyy here -->
            </div>
        </div>

        <script>
            // Menu functionality
            const toggleButton = document.querySelector('.hamburger-btn');
            const closeButton = document.querySelector('.close-btn');
            const navbarLinks = document.querySelector('.links');

            toggleButton.addEventListener('click', () => {
                navbarLinks.classList.toggle('show-menu');
            });

            closeButton.addEventListener('click', () => {
                navbarLinks.classList.remove('show-menu');
            });

            // render cart items from local storage
            function renderCart() {
                const summaryContainer = document.getElementById('summary');
                const cart = JSON.parse(localStorage.getItem('cart')) || [];

                let subtotal = 0;

                cart.forEach(item => {
                    const itemTotal = item.price * item.quantity;
                    subtotal += itemTotal;
                });

                const taxRate = 0.02;
                const shippingRate = 0.05;
                const tax = subtotal * taxRate;
                const shipping = subtotal * shippingRate;
                const total = subtotal + tax + shipping;

                summaryContainer.innerHTML = `
                    <p><span>Subtotal</span> <span>${subtotal.toFixed(2)} JD</span></p>
                    <hr>
                    <p><span>Tax</span> <span>${tax.toFixed(2)} JD</span></p>
                    <hr>
                    <p><span>Shipping</span> <span>${shipping.toFixed(2)} JD</span></p>
                    <hr>
                    <p class="total"><span>Total</span> <span>${total.toFixed(2)} JD</span></p>
                `;

                document.getElementById('total').value = total.toFixed(2);
                document.getElementById('cart').value = JSON.stringify(cart);
            }

            // first render
            document.addEventListener('DOMContentLoaded', renderCart);
        </script>
    </body>

</html>
