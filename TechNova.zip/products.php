<?php
session_start();
include('config.php');

// Get category from URL parameter if set
$category_id = isset($_GET['category']) ? intval($_GET['category']) : null;
$category_name = '';

$query = "SELECT * FROM products";
if ($category_id) {
    $query .= " WHERE category_id = ?";
    // Fetch the category name for display
    $category_stmt = $conn->prepare("SELECT name FROM categories WHERE id = ?");
    $category_stmt->bind_param("i", $category_id);
    $category_stmt->execute();
    $category_result = $category_stmt->get_result();
    $category = $category_result->fetch_assoc();
    $category_name = $category['name'];
    $category_stmt->close();
}

$stmt = $conn->prepare($query);

if ($category_id) {
    $stmt->bind_param("i", $category_id);
}

$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Products<?php echo $category_name ? " - $category_name" : ""; ?> | Tech Nova</title>
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@48,400,0,0">
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
</head>
<body>
    <!-- Navbar Section -->
    <div class="navbar-container">
        <nav class="navbar">
            <div class="hamburger-btn">
                <span class="hamburger-btn material-symbols-rounded">menu</span>
            </div>
            <a href="/index.php" class="logo">
                <h2>Tech Nova</h2>
            </a>
            <ul class="links">
                <span class="close-btn material-symbols-rounded">close</span>
                <li><a href="index.php">Home</a></li>
                <li><a href="/products.php">Products</a></li>
                <li><a href="index.php#aboutus">About Us</a></li>
                <li><a href="index.php#contactus">Contact</a></li>
            </ul>
            <?php if (isset($_SESSION['user_id'])): ?>
                <div class='menuitem shoppingcart'>
                    <a href="cart.php"><i class="fa fa-shopping-cart fa-3x" aria-hidden="true"></i></a>
                </div>
            <?php else: ?>
                <a href="auth.php"><button class="login-btn">LOGIN</button></a>
            <?php endif; ?>
        </nav>
    </div>

    <div class="mainimgcontainer">
        <img src="https://i.ibb.co/H7mZhRy/productspgimage.png" class="mainproductsimg">
    </div>
    <section class="category-nav">
        <ul>
            <li><a href="products.php" class="<?php echo !$category_id ? 'active' : ''; ?>">All</a></li>
            <li><a href="products.php?category=1" class="<?php echo $category_id == 1 ? 'active' : ''; ?>">Accessories</a></li>
            <li><a href="products.php?category=2" class="<?php echo $category_id == 2 ? 'active' : ''; ?>">Phones</a></li>
            <li><a href="products.php?category=3" class="<?php echo $category_id == 3 ? 'active' : ''; ?>">Audio</a></li>
            <li><a href="products.php?category=4" class="<?php echo $category_id == 4 ? 'active' : ''; ?>">Computers</a></li>
        </ul>
    </section>
    <!-- Product List Section -->
    <section class="product-list">
        <?php while ($row = $result->fetch_assoc()): ?>
        <div class="product-card">
            <div class="main-images">
                <img id="<?php echo $row['name']; ?>" class="active" src="<?php echo $row['image_url']; ?>" alt="<?php echo $row['name']; ?>">
            </div>
            <div class="product-details">
                <a href="item.php?id=<?php echo $row['id']; ?>"><span class="product_name"><?php echo $row['name']; ?></span></a>
                <div class="stars">
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bx-star'></i>
                    <i class='bx bx-star'></i>
                </div>
            </div>
            <div class="price-and-button">
                <div class="price">
                    <span class="price_num">JD <?php echo number_format($row['price'], 3); ?></span>
                </div>
                <div class="button">
                    <div class="button-layer"></div>
                    <button onclick="addToCart(<?php echo $row['id']; ?>, '<?php echo $row['name']; ?>', <?php echo $row['price']; ?>, '<?php echo $row['image_url']; ?>')">Add To Cart</button>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </section>

    <script>
        // Menu functionality
        const toggleButton = document.querySelector('.hamburger-btn');
        const closeButton = document.querySelector('.close-btn');
        const navbarLinks = document.querySelector('.links');

        toggleButton.addEventListener('click', () => {
            navbarLinks.classList.toggle('show-menu');
        });

        closeButton.addEventListener('click', () => {
            navbarLinks.classList.remove('show-menu');
        });

        // add item to cart
        function addToCart(productId, productName, productPrice, productImage) {
            <?php if (!isset($_SESSION['user_id'])): ?>
                window.location.href = 'auth.php';
            <?php else: ?>
                let cart = JSON.parse(localStorage.getItem('cart')) || [];
                let product = cart.find(item => item.id === productId);

                if (product) {
                    product.quantity += 1;
                } else {
                    cart.push({ id: productId, name: productName, price: productPrice, image: productImage, quantity: 1 });
                }

                localStorage.setItem('cart', JSON.stringify(cart));
                alert('Product added to cart!');
            <?php endif; ?>
        }
    </script>
</body>
</html>
