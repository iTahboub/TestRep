<?php
$servername = "51.89.86.101"; // server IP address
$username = "tech"; // database username
$password = "technova"; // database password
$dbname = "technova"; // database name
$port = 3306; 

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error . " (Error Code: " . $conn->connect_errno . ")");
} else {
}
?>
