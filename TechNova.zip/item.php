<?php
session_start();
include('config.php');

// get product ID from query string
$product_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// ghetto way to get product details from the database
$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->bind_param("i", $product_id);
$stmt->execute();
$result = $stmt->get_result();
$product = $result->fetch_assoc();
$stmt->close();

// should product be not found,then we redirect to a products page
if (!$product) {
    header("Location: products.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $product['name']; ?> | Tech Nova</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@48,400,0,0">
    <link rel="stylesheet" href="style.css" />
</head>

<body>
    <!-- Navbar Section -->
    <div class="navbar-container">
        <nav class="navbar">
            <div class="hamburger-btn">
                <span class="hamburger-btn material-symbols-rounded">menu</span>
            </div>
            <a href="/index.php" class="logo">
                <h2>Tech Nova</h2>
            </a>
            <ul class="links">
                <span class="close-btn material-symbols-rounded">close</span>
                <li><a href="index.php">Home</a></li>
                <li><a href="/products.php">Products</a></li>
                <li><a href="index.php#aboutus">About Us</a></li>
                <li><a href="index.php#contactus">Contact</a></li>
            </ul>
            <?php if (isset($_SESSION['user_id'])): ?>
                <div class='menuitem shoppingcart'>
                    <a href="cart.php"><i class="fa fa-shopping-cart fa-3x" aria-hidden="true"></i></a>
                </div>
            <?php else: ?>
                <a href="auth.php"><button class="login-btn">LOGIN</button></a>
            <?php endif; ?>
        </nav>
    </div>

    <div class="shipping">
        <p> Free shipping on orders over 50JDs </p>
    </div>

    <div class="product-item-container">
        <img src="<?php echo $product['image_url']; ?>" alt="<?php echo $product['name']; ?>" class="product-image">
        <div class="product-details-container">
            <p class="product-breadcrumb">Products /</p>
            <p class="product-path"><?php echo $product['name']; ?></p>
            <h2 class="product-title"><?php echo $product['name']; ?></h2>
            <div class="product-rating">
                <span class="fa fa-star checked fa-2x"></span>
                <span class="fa fa-star checked fa-2x"></span>
                <span class="fa fa-star checked fa-2x"></span>
                <span class="fa fa-star fa-2x unchecked"></span>
                <span class="fa fa-star fa-2x unchecked"></span>
                <p>3.0</p>
                <p> 1,366 Reviews</p>
            </div>
            <p class="product-description"><?php echo $product['description']; ?></p>
            <div class="product-delivery">
                <i class="fa fa-truck fa-3x" aria-hidden="true"></i>
                <p> Delivery Within 3 Days </p>
            </div>
            <form class="product-quantity-form">
                <input type="number" id="quantity" name="qty" value="1" min="1" max="100">
                <button type="button" id="addToCartButton"> Add to Cart </button>
            </form>
        </div>
    </div>

    <script>
        // Menu functionality
        const toggleButton = document.querySelector('.hamburger-btn');
        const closeButton = document.querySelector('.close-btn');
        const navbarLinks = document.querySelector('.links');

        toggleButton.addEventListener('click', () => {
            navbarLinks.classList.toggle('show-menu');
        });

        closeButton.addEventListener('click', () => {
            navbarLinks.classList.remove('show-menu');
        });

        // add item to cart
        function addToCart(productId, productName, productPrice, productImage) {
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            let quantity = parseInt(document.getElementById('quantity').value);
            let item = cart.find(item => item.id === productId);
            if (item) {
                item.quantity += quantity;
            } else {
                cart.push({ id: productId, name: productName, price: productPrice, image: productImage, quantity: quantity });
            }
            localStorage.setItem('cart', JSON.stringify(cart));
            alert('Product added to cart!');
        }

        document.getElementById('addToCartButton').addEventListener('click', () => {
            addToCart(
                <?php echo $product['id']; ?>,
                '<?php echo $product['name']; ?>',
                <?php echo $product['price']; ?>,
                '<?php echo $product['image_url']; ?>'
            );
        });
    </script>
</body>

</html>
