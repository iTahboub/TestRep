<?php
session_start(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Home | Tech Nova</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@48,400,0,0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <!-- Navbar Section -->
  <div class="navbar-container">
    <nav class="navbar">
        <div class="hamburger-btn">
              <span class="hamburger-btn material-symbols-rounded">menu</span>
          </div>
      <a href="/index.php" class="logo">
        <h2>Tech Nova</h2>
      </a>
      <ul class="links">
        <span class="close-btn material-symbols-rounded">close</span>
        <li><a href="index.php">Home</a></li>
        <li><a href="/products.php">Products</a></li>
        <li><a href="index.php#aboutus">About Us</a></li>
        <li><a href="index.php#contactus">Contact</a></li>
      </ul>
      <?php if (isset($_SESSION['user_id'])): ?>
        <div class='menuitem shoppingcart'>
            <a href="cart.php"><i class="fa fa-shopping-cart fa-3x" aria-hidden="true"></i></a>
        </div>
      <?php else: ?>
        <a href="auth.php"><button class="login-btn">LOGIN</button></a>
      <?php endif; ?>
    </nav>
  </div>
  <img src="Assets/img/home/GlassDevices.png" class="devices">
  <h1>The Ultimate Destination for <br> All Your Electronic Needs </h1>
  <a href="products.php">
    <div class="productsContainer">
      <button class="productsbutton">View Products</button>
    </div>
  </a>
  <h2>Categories</h2>
  <div class='categories-container'>
    <div class='categories-container'>
      <div class="categories-item">
        <a href="products.php?category=1">
          <img src='Assets/img/home/GlassVR.png' class='catpic'>
          <p class='catname'>Accessories</p>
        </a>
      </div>
      <div class="categories-item">
        <a href="products.php?category=2">
          <img src='Assets/img/home/GlassPhone.png' class='catpic'>
          <p class='catname'>Phones</p>
        </a>
      </div>
      <div class="categories-item">
        <a href="products.php?category=3">
          <img src='Assets/img/home/GlassHeadphones.png' class='catpic'>
          <p class='catname'>Audio</p>
        </a>
      </div>
      <div class="categories-item">
        <a href="products.php?category=4">
          <img src='Assets/img/home/GlassLaptop.png' class='catpic'>
          <p class='catname'>Computers</p>
        </a>
      </div>
    </div>
  </div>

  <div class="aboutus">
    <img src="Assets/img/home/GlassRocket.png" id="rocket">
    <h3>ABOUT US</h3>
    <p class="text">
      At TechNova, we bring you the latest technology from the top technology brands, at the lowest price.<br><br>
      We focus on curating an array of products, each handpicked to ensure quality and reliability, offering a one-stop shop to meet all your technological desires.<br><br>
      Just like our name, our products are out of this world.
    </p>
    <br><br>
    <div class='stats'>
      <div class='item'>
        <p class='num'>22K</p>
        <p class='val'>Products Sold</p>
      </div>
      <div class='item'>
        <p class='num'>14k</p>
        <p class='val'>Happy Customers</p>
      </div>
      <div class='item'>
        <p class='num'>67</p>
        <p class='val'>Shipping Locations</p>
      </div>
    </div>
  </div>

  <h1 style="padding:1vw;" id="contactus">Have a Question? Contact Us.</h1>
  <form action="https://google.com" method="GET" class="contactform">
    <input type="text" name="name" placeholder="Name*" required class="contactinput cname"/>
    <input type="email" name="email" placeholder="Email*" required class="contactinput cemail"/>  
    <br>
    <textarea name="question" rows="4" cols="50" required class="contactinput question" placeholder="What can we help you with?"></textarea>
    <br>
    <label for="input-field" id="drop-area" class="question">
      <input type="file" name="fileupload" accept=".png,.jpg,.pdf" id="input-file">
      <div id="img-view">
        <img src="upload.png">
        <p>Drag and drop or choose<br> a file from your computer</p>
      </div>
    </label>
    <input type="submit" value="Submit" class="submitbutton">
  </form>

  

  <script>
    // animate the rocket
    document.addEventListener('DOMContentLoaded', function() {
      var rocket = document.getElementById('rocket');
      var startPositionY = rocket.offsetTop;
      var positionY = startPositionY;
      var isAscending = true;
      var animationFrame;

      function animateRocket() {
        if (isAscending) {
          positionY -= 1; 
          rocket.style.top = positionY + 'px';

          if (positionY <= 0) {
            isAscending = false;
          }
        } else {
          positionY += 1; 
          rocket.style.top = positionY + 'px';

          if (positionY >= startPositionY) {
            positionY = startPositionY; 
            isAscending = true; 
          }
        }

        animationFrame = requestAnimationFrame(animateRocket);
      }

      rocket.addEventListener('mouseover', function() {
        animationFrame = requestAnimationFrame(animateRocket);
      });

      rocket.addEventListener('mouseout', function() {
        cancelAnimationFrame(animationFrame);
      });
    });
    
    // menu functionality all night
    const toggleButton = document.querySelector('.hamburger-btn');
    const closeButton = document.querySelector('.close-btn');
    const navbarLinks = document.querySelector('.links');

    toggleButton.addEventListener('click', () => {
      navbarLinks.classList.toggle('show-menu');
    });

    closeButton.addEventListener('click', () => {
      navbarLinks.classList.remove('show-menu');
    });
  </script>
</body>
</html>
