-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2024 at 10:28 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `technova`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`) VALUES
(1, 'Accessories', 'Accessories and gadgets'),
(2, 'Phones', 'Phones and mobile devices'),
(3, 'Audio', 'Audio items and headphones'),
(4, 'Computers', 'Computers and laptops');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `total` decimal(10,2) NOT NULL,
  `status` varchar(50) DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `streetname` varchar(100) DEFAULT NULL,
  `buildingno` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `total`, `status`, `created_at`, `first_name`, `last_name`, `address`, `email`, `streetname`, `buildingno`) VALUES
(1, 4, 1390.99, 'Pending', '2024-05-25 18:33:25', 'Omar', 'Test', 'test city', 'test@omar.com', 'test street', 'test building'),
(2, 5, 2139.98, 'Pending', '2024-05-25 18:48:11', 'Omar', 'Tahboub', 'omar', 'omar@ggg.com', 'ssss', 'lllll'),
(3, 6, 668.75, 'Pending', '2024-05-25 19:22:12', 'Omar', 'Tahboub', '7th circle', 'omartahboub755@yahoo.com', 'Omar ', '5'),
(4, 6, 21.39, 'Pending', '2024-05-25 19:36:16', 'Omar', 'Tahboub', 'Amman', 'omar.tahboub.9@gmail.com', 'Odkdmd', 'Kdkdkd');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `price`, `created_at`) VALUES
(1, 1, 2, 1, 1299.99, '2024-05-25 18:33:26'),
(2, 2, 1, 1, 699.99, '2024-05-25 18:48:11'),
(3, 2, 2, 1, 1299.99, '2024-05-25 18:48:11'),
(4, 3, 1, 1, 625.00, '2024-05-25 19:22:12'),
(5, 4, 3, 1, 19.99, '2024-05-25 19:36:16');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `category_id`, `image_url`, `created_at`) VALUES
(1, 'Mac Mini M1 8 Core CPU', 'Chip Apple M1 chip 8-core CPU with 4 performance cores and 4 efficiency cores\n    8-core GPU\n    16-core Neural Engine\n\n    Memory 8GB unified memory\n    Storage 512GB SSD\n\n    Electrical and Operating Requirements\n    Line voltage: 100–240V AC\n    Frequency: 50Hz to 60Hz, single phase\n    Maximum continuous power: 150W\n\n    Ports:-\n    Video Support - Audio - Connections and Expansion - Communications - Bluetooth - Ethernet\n\n', 625.00, 4, 'https://i.ibb.co/B4X2C62/1704971620-0406d0baa366a801e41b.png', '2024-05-24 20:00:33'),
(2, 'Dell Latitude 7390 2 in 1', '2 months warrenty\r\nDell Latitude 7390 2-in-1 Laptop\r\nFHD WVA (1920 X 1080) Touchscreen\r\nIntel Quad Core i5-8350U\r\n16GB RAM, 512GB SSD Hard Drive\r\nWindows 10 Pro', 399.00, 4, 'https://i.ibb.co/K2Gw6v4/1690179831-efac2bc4987830243d9d.png', '2024-05-24 20:00:33'),
(3, 'NOTHING Phone 2', 'Type LTPO OLED, 1B colors, 120Hz, HDR10+, 1600 nits (HBM), 1600 nits (peak)\r\nSize 6.7 inches, 108.0 cm2 (~87.2% screen-to-body ratio)\r\nResolution 1080 x 2412 pixels, 20:9 ratio (~394 ppi density)\r\nProtection Corning Gorilla Glass,Always On Display\r\nOS Android 13, Nothing OS 2.0.2a\r\nChipset Qualcomm SM8475 Snapdragon 8+ Gen 1 (4 nm)\r\nCPU Octa-core (1x3.0 GHz Cortex-X2 & 3x2.5 GHz Cortex-A710 & 4x1.80 GHz Cortex-A510)\r\nGPU Adreno 730\r\nInternal 128GB 8GB RAM, 256GB 12GB RAM, 512GB 12GB RAM\r\nDual 50 MP, f/1.9, 24mm (wide), 1/1.56\", 1.0µm, PDAF, OIS\r\n50 MP, f/2.2, 114˚ (ultrawide), 1/2.76\", 0.64µm, AF\r\nFeatures LED flash, panorama, HDR\r\nVideo 4K@30/60fps, 1080p@30/60fps, gyro-EIS, live HDR, OIS\r\nSensors Fingerprint (under display, optical), accelerometer, proximity, gyro, compass\r\nType Li-Ion 4700 mAh, non-removable\r\nCharging 45W wired, PD3.0, PPS, QC4, 100% in 55 min (advertised)\r\n15W wireless, 100% in 130 min (advertised)\r\n5W reverse wireless', 529.99, 2, 'https://i.ibb.co/wzr0HQ9/1701181883-8ca7d1737f793916b7f0.png', '2024-05-24 20:00:33'),
(4, 'Green Lion 2 in 1 Lion Wireless Microphone', 'The Green Lion Wireless Microphone is the ideal recorder for both indoors and outside production. It is a wireless microphone with a Type-C connector that can be used with your smart phones. Just to clarify, all smartphones can connect to it using the Type-C connector.\r\nIt has two excellent features that will notify you when someone speaks into the microphone quietly are the mute button and the cool beep.\r\nSince you are no longer tied to a wire, the wireless connection makes it easier for you to take the microphone around with complete freedom.', 49.99, 3, 'https://i.ibb.co/fGSkqjg/1688473310-99306d10db8e6cc598d4.png', '2024-05-24 20:00:33'),
(5, 'Samsung Galaxy S24+ ', 'DISPLAY Type Dynamic LTPO AMOLED 2X, 120Hz, HDR10+, 2600 nits (peak)\r\nSize 6.7 inches (~91.6% screen-to-body ratio)\r\nResolution 1440 x 3120 pixels, 19.5:9 ratio (~513 ppi density)\r\nProtection Corning Gorilla Glass Victus 2\r\nAlways-on display\r\n\r\nBuild Glass front (Gorilla Glass Victus 2), glass back (Gorilla Glass Victus 2), aluminum frame\r\nSIM Nano-SIM and eSIM\r\nIP68 dust/water resistant (up to 1.5m for 30 min)\r\nArmor aluminum 2 frame with tougher drop and scratch resistance\r\nPLATFORM OS Android 14, One UI 6.1\r\n\r\nChipset Exynos 2400 (4 nm)\r\nCPU 8-core (1x3.39GHz Cortex-X4 & 3x3.1GHz Cortex-A720 & 2x2.9GHz Cortex-A720 & 2x2.2GHz Cortex-A520)\r\nGPU Xclipse 940\r\nInternal 256GB 12GB RAM UFS 4.0\r\n\r\nMAIN CAMERA Triple 50 MP, f/1.8, 24mm (wide), 1/1.56\", 1.0µm, dual pixel PDAF, OIS\r\n10 MP, f/2.4, 67mm (telephoto), 1/3.94\", 1.0µm, PDAF, OIS, 3x optical zoom\r\n12 MP, f/2.2, 13mm, 120˚ (ultrawide), 1/2.55\" 1.4µm, Super Steady video\r\nFeatures LED flash, auto-HDR, panorama\r\nVideo 8K@24/30fps, 4K@30/60fps, 1080p@30/60/240fps, HDR10+, stereo sound rec., gyro-EIS\r\n\r\nSELFIE CAMERA Single 12 MP, f/2.2, 26mm (wide), dual pixel PDAF\r\nFeatures Dual video call, Auto-HDR, HDR10+\r\nVideo 4K@30/60fps, 1080p@30fps\r\n\r\nSOUND Loudspeaker Yes, with stereo speakers\r\n32-bit/384kHz audio, Tuned by AKG\r\nCOMMS WLAN Wi-Fi 802.11 a/b/g/n/ac/6e, tri-band, Wi-Fi Direct\r\nBluetooth 5.3, A2DP, LE\r\nPositioning GPS, GLONASS, BDS, GALILEO, QZSS\r\nNFC Yes\r\nUSB Type-C 3.2, DisplayPort 1.2, OTG\r\n\r\nFEATURES Sensors Fingerprint (under display, ultrasonic), accelerometer, gyro, proximity, compass, barometer\r\nSamsung DeX, Samsung Wireless DeX\r\nUltra Wideband (UWB) support\r\n\r\nBATTERY Type Li-Ion 4900 mAh, non-removable\r\nCharging 45W wired, PD3.0, 65% in 30 min\r\n15W wireless (Qi/PMA)\r\n4.5W reverse wireless', 749.00, 2, 'https://i.ibb.co/N35XWJj/1705591006-91907dc92eda6b3aac70.png', '2024-05-24 20:00:33'),
(6, 'Apple AirPods 2', 'Spatial audio with dynamic head tracking places sound all around you\r\nAdaptive EQ automatically tunes music to your ears\r\nAll-new contoured design\r\nForce sensor lets you easily control your entertainment, answer or end calls, and more\r\nSweat and water resistant\r\nUp to 6 hours of listening time with one charge\r\nUp to 24 hours total listening time with the MagSafe Charging Case\r\nQuick access to Siri by saying “Hey Siri”\r\nEffortless setup, in-ear detection, and automatic switching for a magical experience\r\nEasily share audio between two sets of AirPods on your iPhone, iPad, iPod touch, or Apple TV\r\n', 85.00, 3, 'https://i.ibb.co/Vv1LwR2/1706523483-799c4daa5df4358c82d9.png', '2024-05-25 19:53:55'),
(7, 'iPhone 13 256GB', 'A completely new version of iPhone 13 , offers you an integrated performance with best specifications..!!\r\n\r\nThey come in a beautiful design with elegant flat edges and five great new colours. Both models offer significant innovations\r\nincluding the most advanced two-camera system ever available on an iPhone with a new wide-angle camera with larger pixels and optical image stabilisation with sensor shift (OIS) for better photos and low-light video, and new features such as \"photographic styles\" to personalise the iPhone camera and cinema mode, which brings a new dimension to video storytelling.\r\nIn addition, iPhone 13 and iPhone 13 mini are super fast and energy efficient thanks to the A15 Bionic Chip.\r\nThey have longer battery life and a brighter Super Retina XDR display that brings content to life. \r\nThey are incredibly rugged, thanks to the ceramic shield on the front, and now come with 256 GB of entry-level storage capacity, industry-leading IP68 water protection and advanced 5G.', 999.99, 2, 'https://i.ibb.co/4R2Wr4L/1666181054-b0c415774c47afce7c35.png', '2024-05-25 19:58:33'),
(8, 'Gaming Keyboard and Mouse with RGB Lights', 'Gaming Peripherals Keyboard & Mouse\r\nOptical Gaming Mouse\r\n104 Keys with Mechanical Switch\r\nCompatibility: Windows & Mac\r\n\r\n', 49.99, 1, 'https://i.ibb.co/7jp1b3B/1673526737-b986790195ad241e3da4.png', '2024-05-25 19:59:50'),
(9, 'JOYROOM JR-T13 Pro Wireless Earphones', '35 Newly upgraded Loda original chip, Bluetooth 5.2, fast transmission, stable connection.\r\n5mA ultra-low power consumption, with charging bin can reach 24H lasting life, music always accompany.\r\nBuilt-in call noise reduction technology, filtering external noise, high-definition calls.\r\n    Exclusive ID design, non-sensory and light, comfortable semi-in ear wear.\r\n13mm large speaker unit, AAC high-fidelity audio decoding, enjoy HIFI sound.\r\nInfrared in-ear detection IC, put on play, take off pause, intelligent listening to songs.\r\nNot divided into primary and secondary headphones, single binaural mode without lag switching.\r\nQI standard wireless, direct charging dual choice.\r\nIPX5 level life waterproof, reckless movement.', 35.00, 2, 'https://i.ibb.co/DtWyDxD/1644744312-f359e896cc29ae06c943.png', '2024-05-25 20:01:00'),
(10, 'Gaming Mouse', 'Gaming Peripherals Mouse\r\nOptical Gaming Mouse\r\nCompatibility: Windows & Mac', 25.00, 1, 'https://i.ibb.co/QQMkxFg/1673088863-07608e0ae3a5b3e7f51a.png', '2024-05-25 20:02:08'),
(11, 'Xiaomi Mi AI Speaker', 'Go ahead to another level of performance by purchasing the all-new Mi AI Speaker from Xiaomi..!!\r\nWith the voice control function. Tell it what you want to hear, it will play for you.\r\nFor the intelligent device control function, you can set the alarm clock, check the weather, and ask the road.\r\nFeatures with dual-band WiFi and Bluetooth 4.1 connectivity, convenient to operate.\r\n64-bit Cortex A53 1.2GHz strong CPU ensure high-speed running.\r\nSupports A2DP music playing.\r\nIt is completely clear in sound quality and scratch resistant in characters.\r\nLightweight design, convenient to hold and carry.\r\nABS + PC material, not easy to fade or be damaged.\r\nSupport hands-free calls.', 49.99, 3, 'https://i.ibb.co/S79FRxY/1649752701-82381a831544aea000ba.png', '2024-05-25 20:03:19'),
(12, 'Asus Laptop ROG Zephyrus Duo 16', 'Upgraded Seal is opened for Hardware/Software upgrade only to enhance performance. 16.0\" Wide QXGA (2560x1600) 165Hz WQXGA Display; 802.11ax Wifi, Bluetooth 5.2, Ethernet LAN (RJ-45), 720p HD Webcam, RGB Backlit.\r\n\r\nPowerful Performance with AMD Ryzen 9 6900HX Octa Core 6th Gen AMD Ryzen 9 6900HX 3.30GHz Processor (upto 4.9 GHz, 16MB Cache, 8-Cores, 16-Threads, ); GeForce RTX 3070 Ti 8GB GDDR6 Dedicated Graphics, VR Ready.\r\n\r\nHigh Speed and Multitasking 32GB DDR5 SODIMM; 280W Power Supply, 4-Cell 90 WHr Battery; Black Color.\r\n\r\nEnormous Storage 1TB PCIe NVMe SSD; 1 x HDMI 2.1, 2 USB 3.2 Type-C Gen2, Micro SD Reader, No Optical Drive, Headphone/Microphone Combo Jack., Windows 11 Pro-64.', 1999.99, 4, 'https://i.ibb.co/RQ49hyp/1671349054-e1ffae85c1b2d4ed4934.png', '2024-05-25 20:04:19'),
(13, 'Opus iPhone 15 Clear Case', '\r\n\r\n    Thin, light, and easy to grip this Apple-designed case shows off the brilliant colored finish of iPhone 15 while providing extra protection.\r\n\r\n    Crafted with a blend of optically clear polycarbonate and flexible materials, the case fits right over the buttons for easy use. On the surface, a scratch-resistant coating has been applied to both the interior and exterior. And all materials and coatings are optimized to prevent yellowing over time\r\n\r\n    With built-in magnets that align perfectly with iPhone 15 , this case offers a magical attach experience and faster wireless charging, every time. When it’s time to charge, just leave the case on your iPhone and snap on your MagSafe charger.\r\n\r\n    Like every Apple designed case, it undergoes thousands of hours of testing throughout the design and manufacturing process. So not only does it look great, it’s built to protect your iPhone from scratches and drops.\r\n\r\n', 9.00, 1, 'https://i.ibb.co/c1RrPQD/1716302304-4605e31cce896eb12dfe.png', '2024-05-25 20:05:09');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `email`, `password`, `created_at`) VALUES
(1, 'test', 'test@dfbved.com', '$2y$10$6OTLqVbnubZaATebVS4vsuaL7uRhVCMNC9gxJZsaUNvZb3bg6T25S', '2024-05-25 17:24:11'),
(2, 'Osama Alawna', 'osama@alawna.com', '$2y$10$keL2IUUtXCeZyAewFWOQPu2IryWFuu.Y7DrojLzX71p.GLi2jSexq', '2024-05-25 17:51:34'),
(3, 'Omar', 'omargvre@gmail.com', '$2y$10$P0qDd2o2g32xwKIZLnMGJuF50BF/La6zH766gYW/b3sj0Hcmiqcqu', '2024-05-25 18:25:47'),
(4, 'Omar ', 'omar.tahboub04@gmail.com', '$2y$10$fAS5EAQm7ntrk2xGnkP30e3MKG8pUAUOYunecw9qRCDuAyOJSfbmi', '2024-05-25 18:28:42'),
(5, 'sfvf', 'sdvsf@ergver.com', '$2y$10$.lHUJ8NgU0gdwlJ5iCNh/uS9eny7dLZbP2D534Ll4D9PBNno307dO', '2024-05-25 18:47:31'),
(6, 'Omar Tahboub', 'omartahboub755@yahoo.com', '$2y$10$/gYJ7EYmo7JdsYh3rN1sCOO499TJhEz73Ge/UUcYMkOBbKRDh8/L2', '2024-05-25 19:19:28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
