<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Shopping Cart | Tech Nova</title>
  <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@48,400,0,0">
  <link rel="stylesheet" href="style.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
</head>

<body>
    <!-- Navbar Section -->
    <div class="navbar-container">
        <nav class="navbar">
            <div class="hamburger-btn">
                <span class="hamburger-btn material-symbols-rounded">menu</span>
            </div>
            <a href="/index.php" class="logo">
                <h2>Tech Nova</h2>
            </a>
            <ul class="links">
                <span class="close-btn material-symbols-rounded">close</span>
                <li><a href="index.php">Home</a></li>
                <li><a href="/products.php">Products</a></li>
                <li><a href="index.php#aboutus">About Us</a></li>
                <li><a href="index.php#contactus">Contact</a></li>
            </ul>
            <?php if (isset($_SESSION['user_id'])): ?>
                <div class='menuitem shoppingcart'>
                    <a href="cart.php"><i class="fa fa-shopping-cart fa-3x" aria-hidden="true"></i></a>
                </div>
            <?php else: ?>
                <a href="auth.php"><button class="login-btn">LOGIN</button></a>
            <?php endif; ?>
        </nav>
    </div>

    <div class="cart-wrapper">
        <h1>Shopping Cart</h1>
        <div class="cart-project">
            <div class="cart-shop" id="cart-items">
                <!-- dynamically insert cart here -->
            </div>
            <div class="cart-right-bar" id="summary">
                <!-- dynamically insert summary here -->
            </div>
        </div>
    </div>

    <script>
        // Menu functionality
        const toggleButton = document.querySelector('.hamburger-btn');
        const closeButton = document.querySelector('.close-btn');
        const navbarLinks = document.querySelector('.links');

        toggleButton.addEventListener('click', () => {
            navbarLinks.classList.toggle('show-menu');
        });

        closeButton.addEventListener('click', () => {
            navbarLinks.classList.remove('show-menu');
        });

        // render cart items from local storage
        function renderCart() {
            const cartItemsContainer = document.getElementById('cart-items');
            const summaryContainer = document.getElementById('summary');
            const cart = JSON.parse(localStorage.getItem('cart')) || [];

            cartItemsContainer.innerHTML = '';
            let subtotal = 0;

            cart.forEach(item => {
                const itemTotal = item.price * item.quantity;
                subtotal += itemTotal;

                cartItemsContainer.innerHTML += `
                    <div class="cart-box">
                        <img src="${item.image}" alt="${item.name}">
                        <div class="cart-content">
                            <h3>${item.name}</h3>
                            <h4>Price: ${item.price.toFixed(2)} JD</h4>
                            <div class="cart-unit">
                                <label>Quantity:</label>
                                <input type="number" value="${item.quantity}" min="1" max="100" data-id="${item.id}" onchange="updateQuantity(${item.id}, this.value)">
                            </div>
                            <div class="cart-btn-area">
                                <i class="fa fa-trash"></i>
                                <span class="btn2" onclick="removeItem(${item.id})">Remove</span>
                            </div>
                        </div>
                    </div>
                `;
            });

            const taxRate = 0.02;
            const shippingRate = 0.05;
            const tax = subtotal * taxRate;
            const shipping = subtotal * shippingRate;
            const total = subtotal + tax + shipping;

            summaryContainer.innerHTML = `
                <p><span>Subtotal</span> <span>${subtotal.toFixed(2)} JD</span></p>
                <hr>
                <p><span>Tax</span> <span>${tax.toFixed(2)} JD</span></p>
                <hr>
                <p><span>Shipping</span> <span>${shipping.toFixed(2)} JD</span></p>
                <hr>
                <p><span>Total</span> <span>${total.toFixed(2)} JD</span></p>
                <a href="checkout.php"><i class="fa fa-shopping-cart"></i> Checkout</a>
            `;
        }

        // update item quantity
        function updateQuantity(id, quantity) {
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            cart = cart.map(item => {
                if (item.id === id) {
                    item.quantity = parseInt(quantity);
                }
                return item;
            });
            localStorage.setItem('cart', JSON.stringify(cart));
            renderCart();
        }

        // remove an item from the cart
        function removeItem(id) {
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            cart = cart.filter(item => item.id !== id);
            localStorage.setItem('cart', JSON.stringify(cart));
            renderCart();
        }

        // first render
        document.addEventListener('DOMContentLoaded', renderCart);
    </script>
</body>

</html>
